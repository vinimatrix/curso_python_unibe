import sqlite3
from sqlite3 import Error

sql = sqlite3.connect(r'C:\\Users\\mvini\\OneDrive\\Documentos\\Python Scripts\\clase 3\\Clase 6\\DB\\temp.db')
sql.isolation_level = None
c = sql.cursor()
c.execute("begin")
try:
    c.execute("INSERT INTO temp (Field2,Field3) VALUES ('WILLIAM',5);")
    c.execute("UPDATE temp SET Field2='ROBINSON' WHERE Field1=2;")
    c.execute("updt_tabl")
    c.execute("commit")
except sql.Error:
    print("Failed!")
    c.execute('rollback')

